# Vault 15 – Public Recovery & Communication Node

**Author:** Mike van der Willigen  
**License:** CC0 Public Domain  
**Version:** 1.0

---

## Overview

Vault 15 is the final public node documenting whistleblower evidence, narrative survival, and systemic resilience.

This repository contains:
- Manifest
- Essay: "Dog Logic"
- Live reaction archive
- GitHub-ready truth structure

More at: vault15-mike-vanderwilligen (GitHub public)
